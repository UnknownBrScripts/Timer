﻿using System;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;

namespace Timer_PPT
{
    public partial class ThisAddIn
    {
        private TimerForm overlayForm;

        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            // Oculta a janela de timer inicialmente
            overlayForm = new TimerForm();

            // Intercepta os eventos do PowerPoint para mostrar/esconder o timer
            this.Application.SlideShowBegin += Application_SlideShowBegin;
            this.Application.SlideShowEnd += Application_SlideShowEnd;
        }

        private void Application_SlideShowBegin(PowerPoint.SlideShowWindow Wn)
        {
            // Quando a apresentaÃ§Ã£o comeÃ§a, mostra o Timer por cima de tudo
            if (overlayForm == null || overlayForm.IsDisposed)
            {
                overlayForm = new TimerForm();
            }
            overlayForm.Show();
        }

        private void Application_SlideShowEnd(PowerPoint.Presentation Pres)
        {
            // Quando a apresentaÃ§Ã£o termina, esconde o Timer
            if (overlayForm != null && !overlayForm.IsDisposed)
            {
                overlayForm.Hide();
            }
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
            if (overlayForm != null)
            {
                overlayForm.Dispose();
            }
        }

        #region VSTO generated code
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }
        #endregion
    }
}

