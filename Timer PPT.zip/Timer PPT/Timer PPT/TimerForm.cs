using System;
using System.Drawing;
using System.Windows.Forms;

namespace Timer_PPT
{
    public class TimerForm : Form
    {
        private Label lblTime;
        private Timer timer;
        private int timeRemaining = 300; // 5 minutos em segundos
        private bool isRunning = false;

        // Variáveis para permitir arrastar a janela
        private bool dragging = false;
        private Point dragCursorPoint;
        private Point dragFormPoint;

        public TimerForm()
        {
            // 1. Configurações da Janela (Fundo Invisível e Transparente)
            this.FormBorderStyle = FormBorderStyle.None;
            this.TopMost = true; // Fica sempre por cima do PowerPoint
            this.ShowInTaskbar = false;
            
            // A mágica da transparência real no Windows:
            this.BackColor = Color.Magenta;
            this.TransparencyKey = Color.Magenta;
            
            this.Size = new Size(250, 100);
            this.StartPosition = FormStartPosition.CenterScreen;

            // 2. Configuração do Texto (Label)
            lblTime = new Label();
            lblTime.Text = "05:00";
            lblTime.Font = new Font("Segoe UI", 48, FontStyle.Bold);
            lblTime.ForeColor = Color.FromArgb(239, 130, 6); // Laranja padrão
            lblTime.AutoSize = true;
            lblTime.Location = new Point(0, 0);
            lblTime.Cursor = Cursors.SizeAll; // Mostra cursor de arrastar

            // Eventos para arrastar e iniciar/pausar o timer
            lblTime.MouseDown += LblTime_MouseDown;
            lblTime.MouseMove += LblTime_MouseMove;
            lblTime.MouseUp += LblTime_MouseUp;
            lblTime.DoubleClick += LblTime_DoubleClick;

            this.Controls.Add(lblTime);

            // 3. Configuração do Relógio Interno (Timer)
            timer = new Timer();
            timer.Interval = 1000; // 1 segundo
            timer.Tick += Timer_Tick;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (timeRemaining > 0)
            {
                timeRemaining--;
                UpdateDisplay();
            }
            else
            {
                timer.Stop();
                isRunning = false;
            }
        }

        private void UpdateDisplay()
        {
            int m = timeRemaining / 60;
            int s = timeRemaining % 60;
            lblTime.Text = $"{m:D2}:{s:D2}";
        }

        // --- CONTROLES DE MOUSE (ARRASTAR E CLICAR) ---

        private void LblTime_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                dragging = true;
                dragCursorPoint = Cursor.Position;
                dragFormPoint = this.Location;
            }
            else if (e.Button == MouseButtons.Right) // Clique direito para Iniciar/Pausar
            {
                ToggleTimer();
            }
        }

        private void LblTime_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point dif = Point.Subtract(Cursor.Position, new Size(dragCursorPoint));
                this.Location = Point.Add(dragFormPoint, new Size(dif));
            }
        }

        private void LblTime_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void LblTime_DoubleClick(object sender, EventArgs e)
        {
            // Duplo clique para resetar
            timer.Stop();
            isRunning = false;
            timeRemaining = 300;
            UpdateDisplay();
        }

        public void ToggleTimer()
        {
            if (isRunning)
            {
                timer.Stop();
                isRunning = false;
            }
            else
            {
                if (timeRemaining > 0)
                {
                    timer.Start();
                    isRunning = true;
                }
            }
        }
    }
}
